CREATE DATABASE ENERGYDB2;

USE ENERGYDB2;

-- 1. country table
CREATE TABLE country (
    CID VARCHAR(10) PRIMARY KEY,
    Country VARCHAR(100) UNIQUE
);

SELECT * FROM COUNTRY;

-- 2. emission_3 table
CREATE TABLE emission_3 (
    country VARCHAR(100),
	energy_type VARCHAR(50),
    year INT,
    emission INT,
    per_capita_emission DOUBLE,
    FOREIGN KEY (country) REFERENCES country(Country)
);

SELECT * FROM EMISSION_3;

-- 3. population table
CREATE TABLE population (
    countries VARCHAR(100),
    year INT,
    Value DOUBLE,
    FOREIGN KEY (countries) REFERENCES country(Country)
);

SELECT * FROM POPULATION;

-- 4. production table
CREATE TABLE production (
    country VARCHAR(100),
    energy VARCHAR(50),
    year INT,
    production INT,
    FOREIGN KEY (country) REFERENCES country(Country)
);

SELECT * FROM PRODUCTION;

-- 5. gdp_3 table
CREATE TABLE gdp_3 (
    Country VARCHAR(100),
    year INT,
    Value DOUBLE,
    FOREIGN KEY (Country) REFERENCES country(Country)
);

SELECT * FROM GDP_3;

-- 6. consumption table
CREATE TABLE consumption (
    country VARCHAR(100),
    energy VARCHAR(50),
    year INT,
	consumption INT,
    FOREIGN KEY (country) REFERENCES country(Country)
);

SELECT * FROM CONSUMPTION;

-- What is the total emission per country for the most recent year available?
SELECT COUNTRY,MAX(YEAR) 'RECENT YEAR',SUM(EMISSION) 'TOTAL EMISSION'
FROM EMISSION_3
WHERE YEAR = (SELECT MAX(YEAR) FROM EMISSION_3)
GROUP BY COUNTRY;
/* The analysis shows significant differences in carbon emissions among countries*/

-- What are the top 5 countries by GDP in the most recent year?
SELECT COUNTRY,MAX(YEAR) 'RECENT YEAR',SUM(VALUE) 'GDP'
FROM GDP_3
WHERE YEAR = (SELECT MAX(YEAR) FROM GDP_3)
GROUP BY COUNTRY
ORDER BY SUM(VALUE) DESC
LIMIT 5;
/*The analysis identified China, the United States, India, Japan, and Germany as the top five economies in 2024, highlighting their significant contribution to global GDP.*/

-- Compare energy production and consumption by country and year. 
SELECT P.COUNTRY,P.YEAR,SUM(P.PRODUCTION) 'TOTAL PRODUCTION',SUM(C.CONSUMPTION) 'TOTAL CONSUMPTION'
FROM PRODUCTION P
JOIN CONSUMPTION C
ON P.COUNTRY = C.COUNTRY
AND P.ENERGY = C.ENERGY
AND P.YEAR = C.YEAR
GROUP BY P.COUNTRY,P.YEAR
ORDER BY P.COUNTRY,P.YEAR;
/*Countries with higher energy production generally showed higher energy consumption.*/

-- Which energy types contribute most to emissions across all countries?
SELECT
    energy_type,
    SUM(emission) 'total_emissions'
FROM emission_3
GROUP BY energy_type
ORDER BY total_emissions DESC;
/*Overall CO₂ emissions contributed the most (142,723 MMTonnes CO₂), followed by coal and coke emissions (63,945 MMTonnes CO₂).*/

--  Trend Analysis Over Time
-- How have global emissions changed year over year?
SELECT SUM(EMISSION),YEAR
FROM EMISSION_3
GROUP BY YEAR;
/* The year-over-year rise indicates a continuous upward trend in global carbon emissions.*/

-- What is the trend in GDP for each country over the given years?
SELECT COUNTRY,YEAR,SUM(VALUE) GDP
FROM GDP_3
GROUP BY COUNTRY,YEAR
ORDER BY GDP DESC;
/* The upward GDP trend indicates steady economic growth across the leading economies.*/

-- How has population growth affected total emissions in each country?
SELECT  E.COUNTRY, 
	    SUM(E.EMISSION) 'TOTAL EMISSIONS', 
        P.VALUE 'POPULATION',
        P.YEAR
FROM EMISSION_3 E
JOIN POPULATION P
ON E.COUNTRY = P.COUNTRIES
AND E.YEAR = P.YEAR
GROUP BY E.COUNTRY,E.YEAR,P.VALUE
ORDER BY E.COUNTRY,E.YEAR;
/*Total emissions generally increased as population increased across countries.*/

-- Has energy consumption increased or decreased over the years for major economies?
SELECT COUNTRY,YEAR,SUM(CONSUMPTION) 'TOTAL CONSUMPTION'
FROM CONSUMPTION
WHERE COUNTRY IN ('UNITED STATES','CHINA','INDIA','RUSSIA','JAPAN')
GROUP BY COUNTRY,YEAR
ORDER BY COUNTRY;
/* Energy consumption generally increased over the years for major economies*/

-- What is the average yearly change in emissions per capita for each country?
SELECT COUNTRY,
	   avg(EMISSION) AVG_EMISSION,
       avg(per_capita_emission) per_capita_emission, 
       year
FROM EMISSION_3
GROUP BY COUNTRY,YEAR
ORDER BY COUNTRY;
/*Average emissions differed across countries and showed slight changes over the years.*/

-- Ratio & Per Capita Analysis
-- What is the emission-to-GDP ratio for each country by year?
SELECT E.COUNTRY,
	   ROUND(SUM(E.emission)/G.VALUE,6) 'EMISSION_TO_GDP_RATIO',
       E.YEAR
FROM emission_3 E
JOIN gdp_3 G
     ON E.COUNTRY = G.COUNTRY
     AND E.YEAR = G.YEAR
GROUP BY E.COUNTRY,E.YEAR,G.VALUE
ORDER BY E.COUNTRY,E.YEAR;
/* Lower emission-to-GDP ratios indicate greater economic output for each unit of carbon emissions.*/

-- What is the energy consumption per capita for each country over the last decade?
SELECT C.COUNTRY,
	   ROUND(SUM(C.consumption)/P.VALUE,6) consumption_per_capita,
       C.year
FROM consumption C
JOIN population P
	ON C.country = P.countries
	AND C.year = P.year
GROUP BY C.COUNTRY,C.YEAR,P.VALUE
ORDER BY C.COUNTRY,C.YEAR;
/* Countries with higher energy demand generally recorded higher energy consumption per capita.*/

-- How does energy production per capita vary across countries?
SELECT pr.COUNTRY,
	   ROUND(SUM(pr.production)/pp.VALUE,6) production_per_capita,
       pr.year
FROM production pr
JOIN population pp
	ON pr.country = pp.countries
	AND pr.year = pp.year
GROUP BY pr.COUNTRY,pr.YEAR,pp.VALUE
ORDER BY pr.COUNTRY,pr.YEAR;
/*Energy production per capita varied across countries, with some countries recording very low or zero production per capita during the study period.*/

-- Which countries have the highest energy consumption relative to GDP?
SELECT
    c.country,
    SUM(c.consumption) AS total_consumption,
    SUM(g.Value) AS total_gdp,
    ROUND(SUM(c.consumption) / SUM(g.Value), 6) AS consumption_to_gdp_ratio
FROM consumption c
JOIN gdp_3 g
    ON c.country = g.Country
    AND c.year = g.year
GROUP BY c.country
ORDER BY consumption_to_gdp_ratio DESC
LIMIT 15;
/*Countries with higher energy consumption relative to GDP exhibited lower energy efficiency, with Trinidad and Tobago having the highest consumption-to-GDP ratio.*/

-- What is the correlation between GDP growth and energy production growth?
SELECT
    g.Country,
    g.year,
    g.Value AS GDP,
    SUM(p.production) AS total_energy_production
FROM gdp_3 g
JOIN production p
    ON g.Country = p.country
    AND g.year = p.year
GROUP BY g.Country, g.year, g.Value
ORDER BY g.Country, g.year DESC;
/*Countries with higher GDP generally recorded higher energy production, indicating a positive relationship between economic growth and energy production.*/

--  Global Comparisons
-- What are the top 10 countries by population and how do their emissions compare?
SELECT
    p.countries AS country,
    MAX(p.Value) AS population,
    SUM(e.emission) AS total_emissions
FROM population p
JOIN emission_3 e
    ON p.countries = e.country AND p.year = e.year
GROUP BY p.countries
ORDER BY population DESC
LIMIT 10;
/* Countries with larger populations generally exhibited higher total emissions, though the levels varied across countries.*/

-- Which countries have improved (reduced) their per capita emissions the most over the last decade?
SELECT
    e1.country,
    ROUND(AVG(e1.per_capita_emission), 3) AS emission_2020,
    ROUND(AVG(e2.per_capita_emission), 3) AS emission_2024,
    ROUND(AVG(e1.per_capita_emission) - AVG(e2.per_capita_emission),3) AS reduction
FROM emission_3 e1
JOIN emission_3 e2
    ON e1.country = e2.country
WHERE e1.year = 2020
  AND e2.year = 2023
GROUP BY e1.country
ORDER BY reduction DESC;
/*Most countries showed little or no reduction in per-capita emissions between 2020 and 2023*/

-- What is the global share (%) of emissions by country?
SELECT
    country,
    SUM(emission) AS total_emissions,
    ROUND(
        (SUM(emission) /
        (SELECT SUM(emission) FROM emission_3)) * 100,2)
        AS global_emission_share_percent
FROM emission_3
GROUP BY country
ORDER BY global_emission_share_percent DESC;
/* China accounted for nearly one-third of global carbon emissions, the highest among all countries.*/

-- What is the global average GDP, emission, and population by year?
SELECT g.year,
    ROUND(AVG(g.Value), 2) AS avg_gdp,
    ROUND(AVG(e.total_emission), 2) AS avg_emission,
    ROUND(AVG(p.Value), 2) AS avg_population
FROM gdp_3 g
JOIN (SELECT
        country, year, SUM(emission) AS total_emission
    FROM emission_3
    GROUP BY country, year) e 
    ON g.Country = e.country
    AND g.year = e.year
JOIN population p
    ON g.Country = p.countries AND g.year = p.year
GROUP BY g.year
ORDER BY g.year;
/* The global average GDP, carbon emissions, and population increased steadily from 2020 to 2023.*/